#include <iostream>
#include <string>
#include <random>

struct Lottery
{
	int number1;
	int number2;
};

const Lottery generate_lottery();

void bonus_determine(const Lottery& picked, const Lottery& the_number);

int main()
{
	std::cout << "Enter your first lottery pick: ";

	Lottery picked_lottery;

	std::cin >> picked_lottery.number1;

	std::cout << "Enter your second lottery pick: ";

	std::cin >> picked_lottery.number2;


	auto the_number = generate_lottery();

	std::cout << "The lottery number is " << the_number.number1 << " and " << the_number.number2 << std::endl;

	bonus_determine(picked_lottery, the_number);

	return 0;

}

const Lottery generate_lottery()
{
	std::random_device rd;

	std::default_random_engine engine(rd());

	std::uniform_int_distribution<int> dist(0, 9);

	Lottery the_number;

	//the_number.number1 = dist(engine);
	//the_number.number2 = dist(engine);
	/// for test
	the_number.number1 = 1;
	the_number.number2 = 2;

	return the_number;
}

void bonus_determine(const Lottery& picked, const Lottery& the_number)
{
	bool first_first = picked.number1 == the_number.number1;
	bool second_second = picked.number2 == the_number.number2;

	bool first_second = picked.number1 == the_number.number2;
	bool second_first = picked.number2 == the_number.number1;

	
	if (first_first && second_second)
	{
		std::cout << "Exact match: you win $10,000\n";
	}
	else if (first_second && second_first)
	{
		std::cout << "All match: you win $3,000\n";
	}
	else if (second_first || first_second || first_first || second_second)
	{
		std::cout << "Match one diget: you win $1,000\n";
	}
	else
	{
		std::cout << "Sorry: no match\n";
	}

}
