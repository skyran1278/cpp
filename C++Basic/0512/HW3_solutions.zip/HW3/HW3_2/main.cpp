#include <iostream>
#include <string>
#include <cctype>


std::string caesar_cipher(const std::string& input, const int shift);

char shift_ascii(const char input, const int shift);

int main()
{
	std::cout << "Please input a message:" << std::endl;
	std::string message;
	std::getline(std::cin, message);

	std::cout << "The 'n' position further along the alphabet: " << std::endl;
	int shift;
	std::cin >> shift;

	std::cout << "The encoded message:" << std::endl;

	std::cout << caesar_cipher(message, shift) << std::endl;

	return 0;

}

std::string caesar_cipher(const std::string& input, const int shift)
{
	std::string ret;
	for (const auto& c : input)
	{
		if (isalpha(c))
			ret += shift_ascii(c, shift);
		else
			ret += c;
	}

	return ret;
}

char shift_ascii(const char c, const int shift)
{
	int char_int = (int) c;
	if (isupper(char_int))
	{
		if ((char_int + shift) > (int)'Z')
		{
			return (char) ('A' + shift - 1 - ('Z' - char_int));
		}
		else if ((char_int + shift) < (int)'A')
		{
			return (char) ('Z' + shift + 1 + (char_int - 'A'));
		}
		else
		{
			return (char) (char_int + shift);
		}
	}
	else
	{
		if ((char_int + shift) > (int)'z')
		{
			return (char) ('a' + shift - 1 - ('z' - char_int));
		}
		else if ((char_int + shift) < 'a')
		{
			return (char) ('z' + shift + 1 + (char_int - 'a'));
		}
		else
		{
			return (char) (char_int + shift);
		}
	}
}