#include <iostream>
#include <string>
#include <vector>
#include "Fraction.h"

const int compute_gcd(int lhs, int rhs);

int main()
{
	std::cout << "(1)Enter some fractions terminated by \'#\'\n";

	std::string input;

	Fraction sum;

	while (std::cin >> input && input != "#")
	{
		std::string num;
		std::string den;
		std::string* tmp_str = &num;
		for (const auto& c : input)
		{
			if (c == '/')
			{
				tmp_str = &den;
			}
			else
			{
				*tmp_str += c;
			}	
		}

		Fraction tmp_frac;
		tmp_frac.den = std::stoi(den, nullptr, 10);
		tmp_frac.num = std::stoi(num, nullptr, 10);
		
		if (sum.num == 0) // initial value
		{
			sum = tmp_frac;
		}
		else
		{
			if (sum.den != tmp_frac.den) // Different denominators
			{
				const auto gcd = compute_gcd(sum.den, tmp_frac.den);

				if (gcd == 1)
				{
					const int ratio = sum.den;
					sum.den *= tmp_frac.den;
					sum.num *= tmp_frac.den;

					tmp_frac.den *= ratio;
					tmp_frac.num *= ratio;
				}
				else
				{
					const int ratio1 = sum.den / gcd;
					const int ratio2 = tmp_frac.den / gcd;

					sum.den *= ratio2;
					sum.num *= ratio2;

					tmp_frac.den *= ratio1;
					tmp_frac.num *= ratio1;
				}
			}  // Different denominators

			sum.num += tmp_frac.num;
		}	

	}

	std::cout << "The summation of these fractions: " << sum.num << "/" << sum.den << std::endl;

	std::cout << "\n(2)Enter some fractions terminated by \'#\'\n";

	std::vector<Fraction> reduced_fractions;

	sum.den = 0;
	sum.num = 0;

	while (std::cin >> input && input != "#")
	{
		std::string num;
		std::string den;
		std::string* tmp_str = &num;
		for (const auto& c : input)
		{
			if (c == '/')
			{
				tmp_str = &den;
			}
			else
			{
				*tmp_str += c;
			}
		}

		Fraction tmp_frac;
		tmp_frac.den = std::stoi(den, nullptr, 10);
		tmp_frac.num = std::stoi(num, nullptr, 10);

		int gcd = compute_gcd(tmp_frac.den, tmp_frac.num);

		tmp_frac.den /= gcd;
		tmp_frac.num /= gcd;

		reduced_fractions.push_back(tmp_frac);

		if (sum.num == 0) // initial value
		{
			sum = tmp_frac;
		}
		else
		{
			if (sum.den != tmp_frac.den) // Different denominators
			{
				const auto gcd = compute_gcd(sum.den, tmp_frac.den);

				if (gcd == 1)
				{
					const int ratio = sum.den;
					sum.den *= tmp_frac.den;
					sum.num *= tmp_frac.den;

					tmp_frac.den *= ratio;
					tmp_frac.num *= ratio;
				}
				else
				{
					const int ratio1 = sum.den / gcd;
					const int ratio2 = tmp_frac.den / gcd;

					sum.den *= ratio2;
					sum.num *= ratio2;

					tmp_frac.den *= ratio1;
					tmp_frac.num *= ratio1;
				}
			}  // Different denominators

			sum.num += tmp_frac.num;
		}
	}

	std::cout << "After rduce: ";

	for (const auto& e : reduced_fractions)
	{
		std::cout << e.num << "/" << e.den << " ";
	}

	
	std::cout << "\nThe summation of these fractions: " << sum.num << "/" << sum.den << std::endl;

	int sum_gcd = compute_gcd(sum.num, sum.den);

	sum.num /= sum_gcd;
	sum.den /= sum_gcd;

	std::cout << "The summation after reduce: " << sum.num << "/" << sum.den << std::endl;


	return 0;
}

const int compute_gcd(int lhs, int rhs)
{
	int a, b;

	if (lhs > rhs)
	{
		a = lhs;
		b = rhs;
	}
	else
	{
		a = rhs;
		b = lhs;
	}

	while (b != 0)
	{
		int tmp = a % b;
		a = b;
		b = tmp;
	}

	return a;
}