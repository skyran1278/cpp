#ifndef FRACTION_H
#define FRACTION_H

struct Fraction
{
public:
	int num = 0;
	int den = 0;
};

#endif // FRACTION_H
