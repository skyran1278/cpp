#include <iostream>
#include <vector>
#include <string>

bool find_in_words(std::string& input, std::vector<std::string>& words, std::vector<unsigned>& occurrences);

int main()
{

	std::cout << "Please input a few words:\n";
	std::string word;
	
	std::vector<std::string> words;
	std::vector<unsigned> occurrences;

	while (std::cin >> word && word != "!")
	{
		find_in_words(word, words, occurrences);
	}

	unsigned most_time = 0;

	for (decltype(words.size()) index = 0; index != words.size(); ++index)
	{

		if (occurrences[index] > most_time)
		{
			most_time = occurrences[index];
		}
	}

	for (decltype(words.size()) index = 0; index != words.size(); ++index)
	{
		if (occurrences[index] == most_time)
		{
			std::cout << words[index] << " is the mostly occurs and it has " << most_time << " occurrences.\n";
		}
	}

	return 0;
}

bool find_in_words(std::string& input, std::vector<std::string>& words, std::vector<unsigned>& occurrences)
{
	bool found = false;
	decltype(words.size()) index = 0;
	while (!found && index != words.size())
	{
		if (input == words[index])
		{
			occurrences[index]++;
			return true;
		}

		++index;
	}

	words.push_back(input);
	occurrences.push_back(1);

	return false;

}