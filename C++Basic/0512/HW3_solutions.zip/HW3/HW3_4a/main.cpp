#include <iostream>
#include <vector>
#include <string>

bool find_in_words(std::string& input, std::vector<std::string>& words, std::vector<unsigned>& occurrences);

int main()
{

	std::cout << "Please input a few words:\n";
	std::string word;
	
	std::vector<std::string> words;
	std::vector<unsigned> occurrences;

	while (std::cin >> word && word != "!")
	{
		find_in_words(word, words, occurrences);
	}

	std::string longest_word;
	unsigned times;

	for (decltype(words.size()) index = 0; index != words.size(); ++index)
	{
		const auto& current = words[index];

		if (current.size() > longest_word.size())
		{
			longest_word = current;

			times = occurrences[index];
		}
	}

	std::cout << "The longest word is " << longest_word << " and it has " << times << " occurrences.\n";


	return 0;
}

bool find_in_words(std::string& input, std::vector<std::string>& words, std::vector<unsigned>& occurrences)
{
	bool found = false;
	decltype(words.size()) index = 0;
	while (!found && index != words.size())
	{
		if (input == words[index])
		{
			occurrences[index]++;
			return true;
		}

		++index;
	}

	words.push_back(input);
	occurrences.push_back(1);

	return false;

}