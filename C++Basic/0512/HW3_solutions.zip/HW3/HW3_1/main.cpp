#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using Strings = std::vector<std::string>;

int main()
{
	std::ifstream inf("input.txt");

	std::string line;
	Strings lines;

	while (std::getline(inf, line))
	{
		lines.push_back(line);		
	}

	std::cout << "The first paragraph of the input file is\n\n";

	Strings::size_type index = 0;
	while (lines[index] != "")
	{
		std::cout << lines[index] << std::endl;
		++index;
	}


	return 0;
}