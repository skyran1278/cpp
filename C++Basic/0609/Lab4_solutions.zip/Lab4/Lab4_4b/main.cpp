#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <cctype>
struct Student
{
	std::string name;
	std::string id;
	std::string score;
};

int skip_space(const std::string& data, int node);

double compute_average(const std::vector<Student>& students, char lead = ' ');

int main()
{
	std::cout << "Please enter the filename: ";
	std::string file_name;
	std::cin >> file_name;

	std::ifstream inf(file_name);

	std::string line;
	
	std::vector<Student> students;

	while (std::getline(inf, line))
	{
		if (line[0] != '#')
		{
			Student current_student;
			int node = 0;
			bool find_space = false;
			
			while (!std::isspace(line[node]))
			{
				current_student.name.push_back(line[node]);
				++node;
			}
			
			node = skip_space(line, node);

			while (!std::isspace(line[node]))
			{
				current_student.id.push_back(line[node]);
				++node;
			}

			node = skip_space(line, node);

			while (node != line.size())
			{
				current_student.score.push_back(line[node]);
				++node;
			}

			students.push_back(current_student);
			
		}
	}

	char command;
	std::cout << "Enter the leading char for query (? for default, ! to quit): ";
	while (std::cin >> command && command != '!')
	{
		if (command == '?')
		{
			std::cout << "The average score for all the students is: " << compute_average(students) << std::endl;
		}
		else
		{
			bool found = false;
			for (const auto& s : students)
			{
				if (s.name[0] == command)
					found = true;
			}
			if (found)
				std::cout << "The average score for the students is: " << compute_average(students, command) << std::endl;
			else
				std::cout << "No student records with the leading char " << command << std::endl;
		}
		std::cout << "Enter the leading char for query (? for default, ! to quit): ";
	}


	return 0;

}

int skip_space(const std::string& data, int node)
{
	while (std::isspace(data[node]))
	{
		++node;
	}

	return node;
}

double compute_average(const std::vector<Student>& students, char lead)
{
	double average = 0;
	int count = 0;

	for (const auto& s : students)
	{
		if (lead == ' ')
		{			
			average += std::stod(s.score);
			count += 1;
		}
		else
		{
			if (s.name[0] == lead)
			{
				average += std::stod(s.score);
				count += 1;
			}
		}
	}

	return average / count;

}