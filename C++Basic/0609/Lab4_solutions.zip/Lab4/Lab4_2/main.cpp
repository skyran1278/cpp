#include <iostream>
#include <vector>




int main()
{
	std::cout << "Input the size of your std::vector< std::vector< double > >\n";
	int n1, n2, m1, m2;
	std::cin >> n1 >> m1 >> n2 >> m2;

	std::cout << "Input your 1st std::vector< std::vector< double > >\n";
	std::vector< std::vector< double > > matrix_1(n1, std::vector< double >(m1));
	for (int i = 0; i != n1; ++i)
	{
		for (int j = 0; j != m1; ++j)
		{
			std::cin >> matrix_1[i][j];
		}
	}

	std::cout << "Input your 2nd std::vector< std::vector< double > >\n";
	std::vector< std::vector< double > > matrix_2(n2, std::vector< double >(m2));
	for (int i = 0; i != n2; ++i)
	{
		for (int j = 0; j != m2; ++j)
		{
			std::cin >> matrix_2[i][j];
		}
	}

	std::cout << "Result std::vector< std::vector< double > >:\n";
	std::vector< std::vector< double > > result(n1, std::vector< double >(m2, 0)); // Result std::vector< std::vector< double > > should be initialized!!!!!!!!!!!!
	for (int i = 0; i != n1; ++i)
	{
		for (int j = 0; j != m2; ++j)
		{
			for (int k = 0; k != n2; ++k)
			{
				result[i][j] += matrix_1[i][k] * matrix_2[k][j];
			}
			std::cout << result[i][j] << " ";
		}
		std::cout << std::endl;
	}


	return 0;
}