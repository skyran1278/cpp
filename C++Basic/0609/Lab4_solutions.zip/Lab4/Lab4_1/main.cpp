#include <iostream>
#include <string>
#include <vector>
#include <random>
#include "Card.h"

Card draw();

void print_card(const Card& c);

int main()
{
	std::cout << "Enter a specific number (N): ";
	int n = 0;
	std::cin >> n;

	std::vector<Card> cards;

	for (int time = 0; time != n; ++time)
	{
		bool validated_card = false;

		while (!validated_card)
		{
			Card draw_card = draw();
			validated_card = true;
			for (const auto& c : cards)
			{
				if (draw_card.rank == c.rank && draw_card.suit == c.suit)
					validated_card = false;
			}

			if (validated_card)
			{
				cards.push_back(draw_card);
				print_card(draw_card);
			}
		}
	}
	return 0;
}

Card draw()
{
	std::vector<std::string> suits{ "clubs", "diamonds", "hearts", "spades" };

	std::random_device r;
	std::default_random_engine e1(r());
	std::uniform_int_distribution<int> random_suit(0, 3);
	
	Card draw;

	draw.suit = suits[random_suit(e1)];

	std::uniform_int_distribution<int> random_rank(2, 14);

	draw.rank = random_rank(e1);

	return draw;
}

void print_card(const Card& c)
{
	if (c.rank > 10)
	{
		switch (c.rank)
		{
		case 11:
			std::cout << "J  of ";
			break;
		case 12:
			std::cout << "Q  of ";
			break;
		case 13:
			std::cout << "K  of ";
			break;
		case 14:
			std::cout << "A  of ";
			break;
		}
	}
	else if(c.rank == 10)
		std::cout << c.rank << " of ";
	else
		std::cout << c.rank << "  of ";
	std::cout << c.suit << std::endl;
}