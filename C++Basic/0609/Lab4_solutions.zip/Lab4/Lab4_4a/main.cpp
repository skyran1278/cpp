#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <cctype>
struct Student
{
	std::string name;
	std::string id;
	std::string score;
};

int skip_space(const std::string& data, int node)
{
	while (std::isspace(data[node]))
	{
		++node;
	}

	return node;
}

int main()
{
	std::cout << "Please enter the filename: ";
	std::string file_name;
	std::cin >> file_name;

	std::ifstream inf(file_name);

	std::string line;
	
	std::vector<Student> students;

	while (std::getline(inf, line))
	{
		if (line[0] != '#')
		{
			Student current_student;
			int node = 0;
			bool find_space = false;
			
			while (!std::isspace(line[node]))
			{
				current_student.name.push_back(line[node]);
				++node;
			}
			
			node = skip_space(line, node);

			while (!std::isspace(line[node]))
			{
				current_student.id.push_back(line[node]);
				++node;
			}

			node = skip_space(line, node);

			while (node != line.size())
			{
				current_student.score.push_back(line[node]);
				++node;
			}

			students.push_back(current_student);
			
		}
	}

	for (const auto& e : students)
	{
		std::cout << e.name << "\t" << e.id << " " << e.score << std::endl;
	}


	return 0;

}

