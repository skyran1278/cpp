#include <iostream>
#include <vector>
#include <string>
#include <fstream>
int main()
{
	std::ifstream inf("potter.txt");

	std::string word;

	std::vector<std::string> words;
	std::vector<int> times;

	while (inf >> word)
	{
		bool find_the_same = false;
		for (decltype(words.size()) index = 0; index != words.size() && !find_the_same; ++index)
		{
			if (word == words[index])
			{
				++(times[index]);
				find_the_same = true;
			}
		}
		if (!find_the_same)
		{
			words.push_back(word);
			times.push_back(1);
		}
	}

	for (decltype(words.size()) index = 0; index != words.size(); ++index)
	{
		if (times[index] > 1)
			std::cout << words[index] << " occurs " << times[index] << " times.\n";
	}
	return 0;
}