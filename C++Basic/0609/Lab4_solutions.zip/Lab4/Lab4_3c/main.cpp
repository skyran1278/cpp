#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <cctype>

int main()
{
	std::ifstream inf("potter.txt");

	std::string line;

	std::vector<std::string> lines;

	while (std::getline(inf, line))
	{
		lines.push_back(line);
	}

	int line_no = 0;
	for (const auto& word : lines)
	{
		++line_no;
		std::cout << "Line " << line_no << ": ";
		std::string print;
		for (int index = 0; index != word.size(); ++index)
		{			
			if (std::isspace(word[index]))
			{
				if(print != "Potter" && print != "potter")
					std::cout << print << " ";
				print.clear();
			}
			else
			{
				print.push_back(word[index]);
			}

		}

		if (print != "Potter" && print != "potter")
			std::cout << print << " ";
		print.clear();
		std::cout << std::endl;
	}
	
	return 0;
}