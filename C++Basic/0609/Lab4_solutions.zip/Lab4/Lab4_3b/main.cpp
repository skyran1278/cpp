#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <cctype>
std::string& to_lower(std::string& input);

int main()
{
	std::ifstream inf("potter.txt");

	std::string line;

	std::vector<std::string> lines;

	while (std::getline(inf, line))
	{
		lines.push_back(to_lower(line));
	}

	for (const auto& e : lines)
	{
		for (int index = e.size() - 1; index != -1; --index)
		{
			std::cout << e[index];
		}
		std::cout << std::endl;
	}
	
	return 0;
}

std::string& to_lower(std::string& input)
{
	for (auto& e : input)
	{
		if(std::isalpha(e))
			e = std::tolower(e);
	}
	return input;
}