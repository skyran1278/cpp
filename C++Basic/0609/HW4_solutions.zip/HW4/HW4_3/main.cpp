#include <iostream>
#include <cmath>

void sqrt(double a, double tol);

int main()
{
	double base, tol;
	std::cout << "Please input the number which you want to find square root and the tolerance:\n";
	std::cin >> base >> tol;

	sqrt(base, tol);


}

void sqrt(double a, double tol)
{
	int iter = 1;
	double err = 100;
	double square_root = a;
	double square_root_p = a;
	while (err > tol)
	{
		square_root_p = 0.5 * (square_root + a / square_root);
		err = std::abs(square_root_p - square_root) / std::abs(square_root_p);

		std::cout << iter << ": " << square_root_p << " " << err << std::endl;

		square_root = square_root_p;
		++iter;
	}
}