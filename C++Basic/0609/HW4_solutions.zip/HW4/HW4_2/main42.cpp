#include <iostream>
#include <cmath>
#include <string>
#include <cctype>
void PolarToRectangular(double r, double t, double& x, double& y);

void RectangularToPolar(double x, double y, double& r, double& t);

const std::string to_lower(const std::string& input);

int main()
{
	std::cout << "Please input which coordinate system you want to convert to (Polar/Rec): ";
	std::string system;
	std::cin >> system;

	if (to_lower(system) == "polar")
	{
		std::cout << "Please input the x- and y- coordinates: ";
		double x, y;
		std::cin >> x >> y;
		double r, t;
		RectangularToPolar(x, y, r, t);
		std::cout << "The corresponding Polar coordinate (r, theta) is (" << r << ", " << t << ")\n";
	}
	else
	{
		std::cout << "Please input the r- and theta- coordinates: ";
		double r, t;
		std::cin >> r >> t;
		double x, y;
		PolarToRectangular(r, t, x, y);
		std::cout << "The corresponding Rectangular coordinate (x, y) is (" << x << ", " << y << ")\n";
	}


}

void PolarToRectangular(double r, double t, double& x, double& y)
{
	t /= 180.;
	t *= 4. * std::atan(1);
	x = r * std::cos(t);
	y = r * std::sin(t);
}

void RectangularToPolar(double x, double y, double& r, double& t)
{
	r = std::sqrt(x*x + y*y);
	t = std::atan2(y, x);

	t *= 180.;
	t /= 4. * std::atan(1);

}

const std::string to_lower(const std::string& input)
{
	std::string ret;
	for (const auto& e : input)
	{
		ret.push_back(std::tolower(e));
	}

	return ret;
}