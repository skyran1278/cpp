#include <iostream>
#include <string>
#include <cmath>

void draw_box(int length, int width, char border = '+', char fill = ' ');

std::ostream& draw_row(std::ostream& ostr, int times, char border);

int main()
{
	std::cout << "Input width and length: ";
	int length, width;
	std::cin >> width >> length;
	std::cout << "Input border and fill: ";
	char border, fill;
	std::cin >> border >> fill;

	draw_box(length, width, border, fill);

}

void draw_box(int length, int width, char border, char fill)
{
	draw_row(std::cout << std::endl, width, border) << std::endl;
	
	unsigned column = length -2;
	for (unsigned counter = 0; counter != column; ++counter)
	{
		draw_row(std::cout << border, width - 2, fill) << border << std::endl;
	}

	draw_row(std::cout, width, border) << std::endl << std::endl;



	int double_width = width * 2;
	int half_length = std::ceil((length + 1) / 2);

	unsigned half_column = half_length - 1;

	draw_row(std::cout, double_width, '+') << std::endl;
	for (unsigned counter = 0; counter != half_column; ++counter)
	{
		draw_row(std::cout << '+', double_width - 2, ' ') << '+' << std::endl;
	}
	draw_row(std::cout, double_width, '+') << std::endl;


}

std::ostream& draw_row(std::ostream& ostr, int times, char border)
{
	for (int l = 0; l != times; ++l)
	{
		ostr << border;
	}

	return ostr;
}