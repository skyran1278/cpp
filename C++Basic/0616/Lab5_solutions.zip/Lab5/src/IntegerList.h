#ifndef INTEGER_LIST_H
#define INTEGER_LIST_H
#include <list>
#include <iostream>
class IntegerList
{

	friend std::ostream& print(std::ostream& ostr, const IntegerList& list);

private:

	

	std::list<int> raw_data;

	void initialize(const unsigned begin, const unsigned end = 0);

public:

	using size_type = std::list<int>::size_type;

	IntegerList();

	IntegerList(unsigned nelems);

	IntegerList(unsigned start, unsigned end);

	const IntegerList intersection(const IntegerList& rhs, std::ostream& ostr = std::cout) const;

};

std::ostream& print(std::ostream& ostr, const IntegerList& list);

#endif // INTEGER_LIST_H