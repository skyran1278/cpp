#include <iostream>
#include <string>

int main()
{
	std::string line =  "0123456789";

	auto riter = line.rbegin();
	auto iter = line.begin();

	riter += 5; // *iter ---> 4
	iter += 3; // *iter ---> 3

	std::cout << *riter << std::endl;
	std::cout << *iter << std::endl;

	// insert before the direction of an iterator
	line.insert(riter.base(), 'a');
	line.insert(iter, 'b');

	std::cout << "Insert with iterator: " << line << std::endl;



	// insert after the index
	std::string line2 = "0123456789";

	std::string::size_type index = 5; // ---> 4

	line2.insert(index, "c");

	std::cout << "Insert with index: " << line2 << std::endl;
}