#include <iostream>
#include <string>
#include <cctype>


const std::string filter(const std::string& input);

int main()
{
	std::cout << "Enter an integer (! to quit): ";

	std::string str_int;

	bool is_negative = false;

	while (std::cin >> str_int && str_int != "!")
	{
		if (str_int[0] == '-')
			is_negative = true;

		str_int = filter(str_int);

		if(str_int.size() > 3)
		{
			int counter = 0;

			auto index = str_int.size();
			--index;

			while (index != 0) // not -1 in this case!!
			{
				++counter;
				if (counter % 3 == 0)
				{
					str_int.insert(index, ",");
				}

				--index;
			}			
		}

		std::cout << "The integer with comma is: ";
		if (is_negative)
			std::cout << '-';
		std::cout << str_int << std::endl;
		std::cout << "Enter an integer (! to quit): ";

		is_negative = false;
	}

}

const std::string filter(const std::string& input)
{
	std::string ret;

	for (const auto& e : input)
	{
		if (isdigit(e))
			ret.push_back(e);
	}

	return ret;
}