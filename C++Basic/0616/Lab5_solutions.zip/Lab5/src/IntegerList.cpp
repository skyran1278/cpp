#include "IntegerList.h"
#include <iostream>

void IntegerList::initialize(const unsigned begin, const unsigned end)
{	
	auto lhs = begin;
	auto rhs = end;

	if (end == 0)
	{
		lhs = 0;
		rhs = begin;
	}

	for (int elem = lhs; elem != rhs; ++elem)
	{
		raw_data.push_back(elem);
	}
	
}

IntegerList::IntegerList()
{
	std::cout << "I am a default constructor.\n";
}

IntegerList::IntegerList(unsigned nelems)
{
	initialize(nelems);
}

IntegerList::IntegerList(unsigned start, unsigned end)
{
	initialize(start, end);
}

const IntegerList IntegerList::intersection(const IntegerList & rhs, std::ostream& ostr) const
{
	IntegerList ret;

	ostr << "Intersection elements are: ";

	for(const auto& e1 : raw_data)
		for (const auto& e2 : rhs.raw_data)
		{
			if (e1 == e2)
			{
				ret.raw_data.push_back(e1);
				ostr << e1 << " ";
			}
		}

	ostr << std::endl;

	return ret;
}

std::ostream & print(std::ostream & ostr, const IntegerList & list)
{
	// TODO: insert return statement here
	ostr << "The elements in the IntegerList are: ";

	for (const auto& e : list.raw_data)
	{
		ostr << e << " ";
	}
	return ostr;
}
