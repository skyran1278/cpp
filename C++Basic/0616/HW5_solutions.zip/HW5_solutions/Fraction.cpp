#include "Fraction.h"

Fraction::Fraction(std::istream & istr)
{
	std::cout << "Enter the name for Fraction: ";
	istr >> name;
	std::cout << "Enter the values for numerator and denominator: ";
	istr >> numer >> denom;

}

Fraction::Fraction(const int n, const int d)
	:numer(n), denom(d)
{
}

Fraction&  Fraction::setName(const std::string & in_name)
{
	name = in_name;

	return *this;
}

Fraction & Fraction::setName(const Fraction * frac)
{
	// TODO: insert return statement here
	name = frac->name;

	return *this;
}

std::ostream & printFraction(std::ostream & ostr, const Fraction & frac)
{
	// TODO: insert return statement here

	ostr << "Fraction " << frac.name << ": " << frac.numer << "/" << frac.denom << std::endl;

	return ostr;

}
