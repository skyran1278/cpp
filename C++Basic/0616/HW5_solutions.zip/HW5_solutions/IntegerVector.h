#ifndef INTEGER_VECTOR_H
#define INTEGER_VECTOR_H

#include <vector>
#include <iostream>

class IntegerVector
{
private:

	friend std::ostream& print(std::ostream& ostr, const IntegerVector& ivec);

	std::vector<int> raw_data;

public:
	IntegerVector();
	
	IntegerVector(unsigned in_size);

	IntegerVector(unsigned start, unsigned end);

	const IntegerVector intersection(const IntegerVector& rhs) const;

};

std::ostream& print(std::ostream& ostr, const IntegerVector& ivec);


#endif
