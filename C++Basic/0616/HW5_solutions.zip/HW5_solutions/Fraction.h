#ifndef FRACTION_H
#define FRACTION_H

#include <string>
#include <iostream>

class Fraction
{
	friend std::ostream& printFraction(std::ostream& ostr, const Fraction& frac);

private:

	int numer = 0;
	int denom = 1;

	std::string name = "anonymous";

public:

	Fraction(const Fraction& rhs) = default;

	Fraction(std::istream& istr);

	Fraction(const int n = 0, const int d = 1);

	Fraction& setName(const std::string& in_name);

	Fraction& setName(const Fraction* frac);

};

std::ostream& printFraction(std::ostream& ostr, const Fraction& frac);

#endif // FRACTION_H