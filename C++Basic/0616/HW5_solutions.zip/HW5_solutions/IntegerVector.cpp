#include "IntegerVector.h"

#include <iostream>

IntegerVector::IntegerVector()
	:raw_data()
{
	std::cout << "I am a default constructor.\n";
}

IntegerVector::IntegerVector(unsigned in_size)
	:raw_data(in_size)
{
	for (decltype(raw_data.size()) index = 0; index != raw_data.size(); ++index)
	{
		raw_data[index] = index;
	}
}

IntegerVector::IntegerVector(unsigned start, unsigned end)
	:raw_data(end - start)
{
	auto counter = start;

	for (decltype(raw_data.size()) index = 0; index != raw_data.size(); ++index)
	{
		raw_data[index] = counter++;
	}
}

std::ostream& print(std::ostream& ostr, const IntegerVector& ivec)
{
	ostr << "The elements in the IntegerVector are: ";
	for (const auto& e : ivec.raw_data)
	{
		ostr << e << " ";
	}
	ostr << std::endl;

	return ostr;
}

const IntegerVector IntegerVector::intersection(const IntegerVector& rhs) const
{
	IntegerVector intersected;

	std::cout << "Intersection elements are: ";

	for (const auto& e1 : raw_data)
	{
		for (const auto& e2 : rhs.raw_data)
		{
			if (e1 == e2)
			{
				intersected.raw_data.push_back(e1);
				std::cout << e1 << " ";
			}
		}
	}

	std::cout << std::endl;

	return intersected;

}