#include <iostream>
#include <string>
#include <fstream>
#include <vector>

int main()
{
	std::cout << "Please input the file name.\n";
	std::cout << "input here: ";
	std::string file_name;
	std::cin >> file_name;

	std::ifstream inf(file_name.c_str());

	while (!inf.is_open())
	{
		std::cout << "The file does not exist!\nPlease input the file name again.\ninput here: ";
		std::cin >> file_name;
		inf.open(file_name.c_str());
	}

	if (inf.good())
	{
		std::cout << "File was opened correctly.\n";
	}

	std::string line;
	std::vector<std::string> lines;

	while (std::getline(inf, line))
		lines.push_back(line);

	std::vector<unsigned> puncts(lines.size()); // Amounts of punctuations of each line
	auto whites(puncts);// Amounts of whitespaces of each line
	auto line_no(puncts); // Number of each line (start from 1 to the last one)

	for (decltype(lines.size()) line_index = 0; line_index != lines.size(); ++line_index)
	{
		line_no[line_index] = line_index + 1;

		const auto& this_line = lines[line_index];

		for(const auto& current_char :this_line)
		{
			if (current_char == ' ')
				++whites[line_index];
			else if (ispunct(current_char))
				++puncts[line_index];
			else
			{
				//Do nothing, but close this if-else statement
			}

		}
	}

	unsigned total_punct = 0;
	unsigned total_white = 0;

	for (decltype(puncts.size()) line_index = 0; line_index != lines.size(); ++line_index)
	{
		total_punct += puncts[line_index];
		total_white += whites[line_index];
	}

	std::cout << "Total punctuation: " << total_punct << std::endl;
	std::cout << "Total spaces: " << total_white << "\n\n";

	for (decltype(puncts.size()) line_index = 0; line_index != lines.size(); ++line_index)
	{
		std::cout << "Line " << line_no[line_index] << std::endl;
		std::cout << "\tPunctuation: " << puncts[line_index] << std::endl;
		std::cout << "\tspaces: " << whites[line_index] << "\n\n";
	}




	return 0;
}