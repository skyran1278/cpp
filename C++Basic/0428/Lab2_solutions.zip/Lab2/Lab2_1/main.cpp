#include <iostream>
#include <cmath>

#include "Vertex.h"
#include "Triangle.h"

const double distance(const Vertex& begin, const Vertex& end);

const bool equal_to(const double& lhs, const double& rhs, const double& epsilon = 1.e-12);

int main()
{
	Triangle t;
	std::cout << "Please input the x & y coordinates of the 1st vertex:\n";
	std::cin >> t.a.x >> t.a.y;

	std::cout << "Please input the x & y coordinates of the 2nd vertex:\n";
	std::cin >> t.b.x >> t.b.y;

	std::cout << "Please input the x & y coordinates of the 3rd vertex:\n";
	std::cin >> t.c.x >> t.c.y;

	const auto ab = distance(t.a, t.b);
	const auto bc = distance(t.b, t.c);
	const auto ca = distance(t.c, t.a);

	bool ab_tangent = false;
	bool bc_tangent = false;
	bool ca_tangent = false;


	// ab state
	if (equal_to(bc*bc + ca*ca, ab*ab))
	{
		ab_tangent = true;
	}
	// bc state
	else if (equal_to(ab*ab + ca*ca, bc*bc))
	{
		bc_tangent = true;
	}
	// ca state
	else if (equal_to(ab*ab + bc*bc, ca*ca))
	{
		ca_tangent = true;
	}


	if (ab_tangent || bc_tangent || ca_tangent)
	{
		std::cout << "This is a right triangle !\n";

		if (ab_tangent)
			std::cout << "The right angle is at the Vertex3\n";
		else if (bc_tangent)
			std::cout << "The right angle is at the Vertex1\n";
		else
			std::cout << "The right angle is at the Vertex2\n";
	}
	else
		std::cout << "This is not a right triangle\n";

}

const bool equal_to(const double& lhs, const double& rhs, const double& epsilon)
{
	return std::abs(lhs - rhs) < epsilon;
}

const double distance(const Vertex& begin, const Vertex& end)
{
	const auto dx = end.x - begin.x;
	const auto dy = end.y - begin.y;
	
	return std::sqrt(dx*dx + dy*dy);
}

