#ifndef VERTEX_H
#define VERTEX_H

struct Vertex
{
	double x;
	double y;
};

#endif
