#include <iostream>
#include <vector>

int main()
{
	std::cout << "Enter a sequence of numbers to be summed: ";

	int tmp_number;
	int sum = 0;

	while (std::cin >> tmp_number && tmp_number > 0)
	{
		sum += tmp_number;
	}

	std::cout << "Sum is: " << sum << std::endl;
	return 0;
}