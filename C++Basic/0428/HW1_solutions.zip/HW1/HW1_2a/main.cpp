#include <iostream>

int main()
{
	int the_number = 1233;
	
	int last = 0;
	int first = 0;

	int mod = 10;
	int residual = the_number % mod;
	last += residual;
	the_number -= residual;
	
	mod *= 10;
	residual = the_number % mod;
	last += residual;
	the_number -= residual;

	mod *= 10;
	residual = the_number % mod;
	first += residual;
	the_number -= residual;

	mod *= 10;
	residual = the_number % mod;
	first += residual;
	the_number -= residual;

	first /= 100;

	std::cout << first*first + last*last << " == " << first << "*" << first << " + " << last << "*" << last << std::endl;

	///
	the_number = 8833;

	last = 0;
	first = 0;

	mod = 10;
	residual = the_number % mod;
	last += residual;
	the_number -= residual;

	mod *= 10;
	residual = the_number % mod;
	last += residual;
	the_number -= residual;

	mod *= 10;
	residual = the_number % mod;
	first += residual;
	the_number -= residual;

	mod *= 10;
	residual = the_number % mod;
	first += residual;
	the_number -= residual;

	first /= 100;

	std::cout << first*first + last*last << " == " << first << "*" << first << " + " << last << "*" << last << std::endl;


	return 0;
}