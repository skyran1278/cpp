#include <iostream>

int main()
{
	int the_number = 1233;

	int last = 0;
	int first = 0;

	int is_first = 0;
	int mod = 10;
	while (mod != 1e5)
	{
		int residual = the_number % mod;
		if (is_first < 2)
		{
			last += residual;
		}
		else
		{
			first += residual;
		}
		the_number -= residual;

		//update
		++is_first;
		mod *= 10;
	}
	first /= 100;

	std::cout << first*first + last*last << " == " << first << "*" << first << " + " << last << "*" << last << std::endl;

	return 0;
}